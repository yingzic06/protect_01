"""已知完整赛道边界的最速圈控制器。

思路(详见 思路.md):
  1. 离线规划(__init__ 内完成,约 0.3s,限时 60s):
     a) 最小曲率赛车线:以「中心线 + 沿法向的横向偏移」为变量,迭代
        「平滑(最小化二阶差分,均匀采样下近似曲率平方和) + 投影回可行域」;
        可行域 = 参考点到两侧边界各留 margin(半车宽 + 地图扰动 + 跟踪误差);
     b) 车身校验:沿路线取车身矩形四角,要求「都在赛道内且到两条边界的
        最近距离 >= 3cm(验收地图抖动幅度)」,违例点向中心线回收并局部平滑,
        若干轮仍违例就整体加大 margin 重来,最终兜底退回中心线;
     c) 速度规划:按最终路线曲率给弯道限速 sqrt(a_lat/|kappa|);
        反向遍历按摩擦圆算入弯刹车点(刹车占用纵向抓地,侧向余量变小),
        正向遍历按驱动上限 0.3G 算出弯加速;
        一律按最差 mu = 0.92 x 标称 规划,给验收的 -10% 摩擦扰动留余量。
  2. 在线控制(每 0.02s 一步,平均耗时约 0.1ms,限 20ms):
     · 窗口内最近点定位(防止在窄道相邻路段间跳点);
     · 纯追踪算转角,指令转角速率按舵机 -20% 限幅(舵机再慢也跟得上);
     · 速度表按 v*tau 向前预瞄(补偿电机一阶响应,tau 取 0.35*1.2 再加余量);
     · 横向误差过大时限速;检测到推头(实际横摆角速度明显小于转向期望,
       即摩擦圆已饱和)时压速度,防止扰动版上带速入弯往外冲。
"""
from __future__ import annotations

import math

import numpy as np

from fastsim import CarParams, DT, State, Track

# ---------------- 规划参数 ----------------
MARGIN = 0.24          # 参考点(后轴中心)到边界最小距离:半车宽0.175+抖动0.03+跟踪余量
SMOOTH_ITERS = 4000    # 赛车线平滑迭代数
SMOOTH_LR = 0.05       # 平滑步长(目标函数 Hessian 上界 32,需 < 0.0625)
REPAIR_ROUNDS = 12     # 车身校验-回收的轮数
MARGIN_FALLBACK = (0.28, 0.32)   # 校验不过时逐级加大的 margin

# 速度规划余量(验收扰动:mu -10%,舵机/电机 -20%,观测噪声)
MU_PLAN = 0.95         # 规划摩擦系数 = 标称 x 0.95(最差 mu -10% 时靠余量与推头保护兜底)
LAT_F = 1.0            # 弯道侧向加速度占用比例
BRAKE_F = 0.95         # 刹车减速度占用比例(摩擦圆内)
DEC_FLOOR = 0.38       # 弯中联合工况刹车下限(占规划 mu*g 比例),防止反向传播卡死
ACC_F = 0.90           # 出弯加速度占用比例(0.3G 为驱动上限,与摩擦圆取小)

# ---------------- 跟踪参数 ----------------
LOOK0, LOOK_GAIN, LOOK_MAX = 0.28, 0.28, 1.0   # 纯追踪前瞻 = LOOK0 + LOOK_GAIN*v
PREVIEW_T = 0.48       # 速度预瞄时间 s(> 0.35 x 1.2 最差响应)
STEER_RATE_F = 0.8     # 指令转角速率限幅系数(舵机最差 -20%)
E_WARN = 0.16          # 横向误差报警阈值 m,超过按比例压速度
UNDER_RATIO = 0.88     # 推头判定:实际横摆角速度 / 转向期望 低于该值
UNDER_SHED = 0.88      # 推头时速度指令乘子(每步重算,温和收油恢复侧向抓地)


# ================= 离线规划 =================

def _dist_to_poly(pts: np.ndarray, poly: np.ndarray) -> np.ndarray:
    """每个点到闭合折线的最近距离(点到线段,精确)。与 fastsim.track 内部实现一致。"""
    a, b = poly, np.roll(poly, -1, axis=0)
    ab = b - a
    len2 = np.maximum((ab ** 2).sum(axis=1), 1e-12)
    t = np.clip(((pts[:, None, :] - a[None]) * ab[None]).sum(axis=2) / len2[None], 0.0, 1.0)
    near = a[None] + t[..., None] * ab[None]
    d = pts[:, None, :] - near
    return np.hypot(d[..., 0], d[..., 1]).min(axis=1)


def _signed_curvature(p: np.ndarray) -> np.ndarray:
    """闭合折线每点的有符号曲率(左转/逆时针为正),外接圆公式。"""
    a, b, c = np.roll(p, 1, axis=0), p, np.roll(p, -1, axis=0)
    ab, bc, ca = b - a, c - b, a - c
    cross = ab[:, 0] * bc[:, 1] - ab[:, 1] * bc[:, 0]
    la = np.hypot(ab[:, 0], ab[:, 1])
    lb = np.hypot(bc[:, 0], bc[:, 1])
    lc = np.hypot(ca[:, 0], ca[:, 1])
    return 2.0 * cross / np.maximum(la * lb * lc, 1e-9)


def _body_corners(p: np.ndarray, heading: np.ndarray, car: CarParams) -> np.ndarray:
    """每个位姿 (x,y,yaw) 的车身矩形四角,返回 (n,4,2)。"""
    lx = np.array([-car.rear_overhang, car.length - car.rear_overhang,
                   car.length - car.rear_overhang, -car.rear_overhang])
    ly = np.array([car.width / 2, car.width / 2, -car.width / 2, -car.width / 2])
    c, s = np.cos(heading)[:, None], np.sin(heading)[:, None]
    return np.stack([p[:, 0:1] + lx[None] * c - ly[None] * s,
                     p[:, 1:2] + lx[None] * s + ly[None] * c], axis=2)


def _tangent(path: np.ndarray) -> np.ndarray:
    t = np.roll(path, -1, axis=0) - np.roll(path, 1, axis=0)
    return t / np.hypot(t[:, 0], t[:, 1])[:, None]


def _line_violation(track: Track, car: CarParams, path: np.ndarray) -> np.ndarray:
    """路线每点车身是否违规:四角(和参考点)出赛道,或离任一边界不足地图抖动幅度。"""
    tan = _tangent(path)
    head = np.arctan2(tan[:, 1], tan[:, 0])
    corners = _body_corners(path, head, car)              # (n,4,2)
    pts = np.vstack([path, corners.reshape(-1, 2)])       # 参考点 + 四角
    ok_in = track.on_track(pts)
    d = np.minimum(_dist_to_poly(pts, track.left), _dist_to_poly(pts, track.right))
    bad = (~ok_in) | (d < 0.03 + 1e-6)
    n = len(path)
    return bad[:n] | bad[n:].reshape(n, 4).any(axis=1)


def _optimize_offsets(track: Track, margin: float, iters: int = SMOOTH_ITERS) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """最小化二阶差分的迭代平滑 + 可行域投影,返回 (offset, normal, lo, hi)。"""
    c = track.centerline
    normal, dl, dr = track.bounds()
    lo = np.minimum(dr - margin, 0.0)     # 右边界在负法向 -dr 处
    hi = np.maximum(dl - margin, 0.0)     # 左边界在正法向 +dl 处
    o = np.zeros(len(c))
    for _ in range(iters):
        p = c + o[:, None] * normal
        g = 2.0 * (np.roll(p, 2, axis=0) - 4.0 * np.roll(p, 1, axis=0) + 6.0 * p
                   - 4.0 * np.roll(p, -1, axis=0) + np.roll(p, -2, axis=0))
        o = np.clip(o - SMOOTH_LR * (g * normal).sum(axis=1), lo, hi)
    return o, normal, lo, hi


def _dilate(mask: np.ndarray, k: int = 2) -> np.ndarray:
    m = mask.copy()
    for _ in range(k):
        m |= np.roll(m, 1) | np.roll(m, -1)
    return m


def _smooth_offsets(o: np.ndarray, passes: int = 3) -> np.ndarray:
    """对偏移序列做几次 [1,2,1] 卷积,消除回收点造成的折角(闭合序列)。"""
    for _ in range(passes):
        o = (np.roll(o, 1) + 2.0 * o + np.roll(o, -1)) * 0.25
    return o


def plan(track: Track, car: CarParams) -> np.ndarray:
    """规划赛车线 (n,2)。先按基础 margin 优化,车身校验不过则回收违例点、加大 margin 重试。"""
    c = track.centerline
    for margin in (MARGIN,) + MARGIN_FALLBACK:
        o, normal, lo, hi = _optimize_offsets(track, margin)
        for _ in range(REPAIR_ROUNDS):
            p = c + o[:, None] * normal
            viol = _line_violation(track, car, p)
            if not viol.any():
                return p
            o[_dilate(viol)] *= 0.8          # 违例点向中心线回收
            o = _smooth_offsets(o)           # 轻度平滑消折角,下一轮再查
        p = c + o[:, None] * normal
        if not _line_violation(track, car, p).any():
            return p
    return c.copy()                           # 兜底:中心线一定可跑


def speed_profile(path: np.ndarray, car: CarParams) -> np.ndarray:
    """按路线曲率做摩擦圆速度规划,返回每点允许车速。"""
    n = len(path)
    closed = np.vstack([path, path[:1]])
    ds = np.hypot(*np.diff(closed, axis=0).T)
    kappa = np.abs(_signed_curvature(path))

    mu_g = MU_PLAN * car.mu * car.g           # 规划用总抓地(最差 mu)
    v = np.sqrt(np.where(kappa > 1e-9, LAT_F * mu_g / np.maximum(kappa, 1e-9), np.inf))
    v = np.minimum(v, car.v_max)

    v = v.copy()
    floor = DEC_FLOOR * mu_g
    for i in range(n - 1, -1, -1):            # 反向:入弯刹车(摩擦圆:纵向占用侧向余量)
        j = (i + 1) % n
        a_lat_next = v[j] * kappa[j]
        a_dec = BRAKE_F * math.sqrt(max(mu_g ** 2 - a_lat_next ** 2, floor ** 2))
        v[i] = min(v[i], math.sqrt(v[j] ** 2 + 2.0 * ds[i] * a_dec))
    for i in range(n):                        # 正向:出弯加速(驱动上限与摩擦圆取小)
        j = (i + 1) % n
        a_acc = ACC_F * min(car.accel_g * car.g,
                            math.sqrt(max(mu_g ** 2 - (v[i] * kappa[i]) ** 2, 0.0)))
        v[j] = min(v[j], math.sqrt(v[i] ** 2 + 2.0 * ds[i] * a_acc))
    return np.maximum(v, 0.3)                 # 不给 0,保证完赛


# ================= 在线控制 =================

class Controller:
    def __init__(self, track: Track, car_params: CarParams):
        self.p = car_params
        self.path = plan(track, car_params)
        self.speed = speed_profile(self.path, car_params)
        self.tan = _tangent(self.path)
        self.heading = np.arctan2(self.tan[:, 1], self.tan[:, 0])
        self.ds = np.hypot(*np.diff(np.vstack([self.path, self.path[:1]]), axis=0).T)
        self.ds_mean = float(self.ds.mean())
        self.n = len(self.path)
        self.idx = None                       # 当前最近路线点下标
        self.steer_cmd = 0.0                  # 上一拍指令转角(指令速率限幅用)

    # -- 定位:窗口内最近点 --
    def _locate(self, x: float, y: float, v: float) -> int:
        n = self.n
        if self.idx is None:                  # 起点在中心线首点,只在起点附近找
            win = np.arange(-20, 80) % n
        else:                                 # 之后向前找:后退 0.5m,前探 0.5m + 一个步长余量
            back, fwd = 10, 10 + int(0.15 * max(v, 0.0) / self.ds_mean) + 60
            win = (self.idx + np.arange(-back, fwd)) % n
        d = (self.path[win, 0] - x) ** 2 + (self.path[win, 1] - y) ** 2
        self.idx = int(win[np.argmin(d)])
        return self.idx

    def __call__(self, state: State) -> tuple[float, float]:
        p = self.p
        x, y, yaw, v = state.x, state.y, state.yaw, state.v
        i = self._locate(x, y, v)

        # --- 转角:纯追踪 ---
        look = min(max(LOOK0 + LOOK_GAIN * v, LOOK0), LOOK_MAX)
        k = (i + max(1, int(look / self.ds_mean))) % self.n
        tx, ty = self.path[k]
        dx, dy = tx - x, ty - y
        alpha = math.atan2(dy, dx) - yaw
        steer_pp = math.atan2(2.0 * p.wheelbase * math.sin(alpha), max(math.hypot(dx, dy), 1e-6))
        rate = STEER_RATE_F * p.steer_rate * DT
        self.steer_cmd += min(max(steer_pp - self.steer_cmd, -rate), rate)
        self.steer_cmd = min(max(self.steer_cmd, -p.max_steer), p.max_steer)

        # --- 速度:预瞄速度表 ---
        j = (i + int(v * PREVIEW_T / self.ds_mean)) % self.n
        v_cmd = float(self.speed[j])

        # --- 安全限速 ---
        # 1) 横向误差过大(被扰出去)先减速,给转向留抓地
        rel = np.array([x - self.path[i, 0], y - self.path[i, 1]])
        e = self.tan[i, 0] * rel[1] - self.tan[i, 1] * rel[0]      # 左正
        if abs(e) > E_WARN:
            v_cmd *= max(0.3, 1.0 - (abs(e) - E_WARN) * 3.0)
        # 2) 推头检测:摩擦圆饱和导致实际横摆远小于转向期望,温和收油
        if v > 0.8 and abs(state.steer) > 0.08:
            yr_exp = v * math.tan(state.steer) / p.wheelbase
            if abs(state.yaw_rate) < UNDER_RATIO * abs(yr_exp):
                v_cmd = min(v_cmd, v * UNDER_SHED)

        return float(max(v_cmd, 0.0)), float(self.steer_cmd)
